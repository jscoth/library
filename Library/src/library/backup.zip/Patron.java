package library;

public class Patron {
	String id;
	String firstName;
	String LastName;
	public Patron(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		LastName = lastName;
	}
	
	public String getId() {
		return id;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return LastName;
	}
	
	
}
